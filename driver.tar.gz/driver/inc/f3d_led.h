/*f3d_led.h
*
*Author: Priya Saravanan and Jeremiah Meert
*psaravan and jwmeert
*Date created: 1/26/18
*Last modified by: Jeremiah Meert
*Date Last modified: 1/26/18
Assignment: Lab 3
Part of: C335 Spring 2018

*/

/* declarations for f3d_led.c */



void f3d_led_init(void);
 void f3d_led_on(int);
 void f3d_led_off(int);
 
void f3d_led_all_on(void);
 void f3d_led_all_off(void);
