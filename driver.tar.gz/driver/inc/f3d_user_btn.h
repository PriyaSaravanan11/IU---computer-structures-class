/*f3d_user_btn.h
* declarations for f3d_user_btn.c
*Author: Priya Saravanan and Jeremiah Meert
*psaravan and jwmeert
*Date created: 1/26/18
*Last modified by: Jeremiah Meert
*Date Last modified: 1/26/18
Assignment: Lab 3
Part of: C335 Spring 2018

*/
 

void f3d_usr_btn_init(void); 
int user_btn_read(void);
