
void f3d_uart_init(void);
int putchar(int);
int getchar(void);
void putstring(char *);


