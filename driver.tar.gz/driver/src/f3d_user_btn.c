/* f3d_user_btn.c
**********************************
 *f3d_user_btn.c 
 *contains the init and read functions for the User Button
 *********************************
*Author: Priya Saravanan and Jeremiah Meert
*psaravan and jwmeert
*Date created: 1/26/18
*Last modified by: Jeremiah Meert
*Date Last modified: 1/26/18
Assignment: Lab 3
Part of: C335 Spring 2018

*/

#include <stm32f30x.h>
#include <stm32f30x_gpio.h>
#include <stm32f30x_rcc.h>


/*Initialization of the UserButton*/
void f3d_user_btn_init(void){

  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_StructInit(&GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);

  GPIO_Init(GPIOA, &GPIO_InitStructure);
}

/*reads the User Button*/
int user_btn_read(void){
  return GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0);
}

